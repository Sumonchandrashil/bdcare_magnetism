<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateBookedPackagesTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('booked_packages', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->char('name', 50)->nullable();
			$table->char('number', 50)->nullable();
			$table->char('email', 50)->nullable();
			$table->text('address', 65535)->nullable();
			$table->integer('package_id')->nullable();
			$table->integer('status')->nullable()->default(0);
			$table->integer('created_by')->nullable();
			$table->integer('updated_by')->nullable();
			$table->softDeletes();
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('booked_packages');
	}

}
